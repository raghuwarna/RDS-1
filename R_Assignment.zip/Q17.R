result_vec[3:6] <- rep(c(-0.1, -100), each=2)
result_vec
# Output:
# 2 4 -0.1 -0.1 -100 -100 12
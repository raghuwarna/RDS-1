
vec <- c(3,1,2,3,1,2,3,1,2)
vec <- rep(2, length(vec))
vec
# Output:
# 2 2 2 2 2 2 2 2 2
vec <- c(2, 0.5, 1, 2, 0.5, 1, 2, 0.5, 1)
vec <- vec / vec
vec
# Output:
# 1 1 1 1 1 1 1 1 1
result_vec <- rep(c(2, 4, 6), each=1) * rep(c(1, 2), length.out=6)
result_vec
# Output:
# 2 4 6 4 8 12
vec <- c(seq(3, 6, length.out=5), rep(c(2, -5.1, -33), 2), 7/42 + 2)
extracted <- c(vec[1], vec[length(vec)])
extracted
# Output:
# 3.0 2.1667
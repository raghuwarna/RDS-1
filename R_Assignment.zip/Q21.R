vec <- rep(c(-2, 4, -6, 8, -10), times=3, each=5)
vec <- c(15:25, rep(4.2, 2), -5, seq(200, length(vec), length.out=12))
length(vec)
# Output:
# 26